import { TwitterDownloader } from '../types/index.js';
export declare function twitterdl(url: string): Promise<TwitterDownloader[]>;
//# sourceMappingURL=twitter.d.ts.map