import { Aiovideodl } from '../types/index.js';
export default function aiovideodl(url: string): Promise<Aiovideodl>;
//# sourceMappingURL=aiovideodl.d.ts.map