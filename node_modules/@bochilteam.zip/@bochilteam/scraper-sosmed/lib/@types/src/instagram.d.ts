import { InstagramDownloader, InstagramStory } from '../types/index.js';
export declare function instagramdl(url: string): Promise<InstagramDownloader>;
export declare function instagramStory(name: string): Promise<InstagramStory>;
//# sourceMappingURL=instagram.d.ts.map