import { GroupWA } from '../types/index.js';
export declare function groupWA(query: string): Promise<GroupWA[]>;
//# sourceMappingURL=groupWA.d.ts.map