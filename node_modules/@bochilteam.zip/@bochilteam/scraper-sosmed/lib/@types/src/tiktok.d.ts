import { TiktokDownloader } from '../types/index.js';
export declare function tiktokdl(url: string): Promise<TiktokDownloader>;
//# sourceMappingURL=tiktok.d.ts.map