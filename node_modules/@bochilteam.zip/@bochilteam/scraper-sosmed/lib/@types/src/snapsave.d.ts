import { SnapSave } from '../types/index.js';
export default function snapsave(url: string): Promise<SnapSave[]>;
//# sourceMappingURL=snapsave.d.ts.map