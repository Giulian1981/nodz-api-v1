import { YoutubeSearch } from '../types/index.js';
export default function youtubeSearch(query: string): Promise<YoutubeSearch>;
//# sourceMappingURL=youtube-search.d.ts.map